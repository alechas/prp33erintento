<html>
<head>
<title>Estacionamiento</title>
</head>
<body>	hacer una grilla con un boton para despachar
		<script type="text/javascript" src="java.js"></script>
		<script type="text/javascript" src="java.js"></script>

        <input type="text" name= "patente" id = "patente" value = "   Ingrse Patente        ">
        <br>
        <input class= "button-3d" animated = "glowing" type="button" onclick="DespacharAuto()" name= "despacharAuto" id = "despacharAuto" value = "   Despachar    ">
</body>
</html>