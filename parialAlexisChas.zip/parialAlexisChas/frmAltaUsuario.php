<html>
<head>
<title>Rec1</title>
</head>
<body> 
        <script type="text/javascript" src="java.js"></script>
        <script type="text/javascript" src="java.js"></script>
        <link rel="stylesheet" type="text/css" href="buttons.css">

        <input type="text" name= "nombre" id = "nombre" placeholder= "   Ingrse nombre     ">
        <br>
        <input type="text" name= "mail" id = "mail" placeholder= "   Ingrse mail     ">
        <br>
        <input type="password" name= "pass" id = "pass" placeholder= "   Ingrse contraseña     ">
        <br>
        <input class= "button-3d" animated = "glowing" type="button" onclick="CrearUsuario()" value = "   Crear                     ">
        <br>

</body>
</html>